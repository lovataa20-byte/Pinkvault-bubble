package com.pinkvault.app
import android.animation.ValueAnimator
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.view.Gravity.*
import android.widget.*
import kotlinx.coroutines.*
import kotlin.math.abs

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val INK = 0xFF5B3A55.toInt(); private val PINK = 0xFFFF8FBF.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("pv", "Bubble aktif", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "pv").setContentTitle("PinkVault Bubble aktif 💗").setContentText("Ketuk bubble untuk membuka teks tersimpan")
            .setSmallIcon(android.R.drawable.ic_menu_edit).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        closePanel(); removeBubble(); addBubble()
        return START_STICKY
    }
    private fun removeBubble() { bubble?.let { runCatching { wm.removeView(it) } }; bubble = null }
    private fun closePanel() { panel?.let { runCatching { wm.removeView(it) } }; panel = null }
    override fun onDestroy() { closePanel(); removeBubble(); scope.cancel(); super.onDestroy() }

    private fun addBubble() {
        val p = U.prefs(this); val dm = resources.displayMetrics; val size = dp(p.getInt("size", 56))
        val tv = TextView(this).apply {
            text = "💗"; gravity = CENTER; textSize = size / dm.density * 0.4f; alpha = 0.95f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFFE4F0.toInt()); setStroke(dp(3), PINK) } }
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = TOP or START; x = p.getInt("bx", dm.widthPixels - size); y = p.getInt("by", (dm.heightPixels * 0.4f).toInt()) }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> { val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                        if (abs(mx) > 10 || abs(my) > 10) moved = true
                        if (moved) { lp.x = sx + mx; lp.y = sy + my; wm.updateViewLayout(v, lp) } }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel() else {
                        val tx = if (lp.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                        ValueAnimator.ofInt(lp.x, tx).apply { duration = 200
                            addUpdateListener { lp.x = it.animatedValue as Int; runCatching { wm.updateViewLayout(v, lp) } }; start() }
                        p.edit().putInt("bx", tx).putInt("by", lp.y).apply()
                    }
                }
                return true
            }
        })
        wm.addView(tv, lp); bubble = tv
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun btn(t: String, small: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { click() }
        if (small) { textSize = 12f; minHeight = 0; minimumHeight = 0; setPadding(dp(10), dp(4), dp(10), dp(4)) } }

    private fun openPanel() {
        val dm = resources.displayMetrics; var cat = ""; var q = ""
        val pin = U.prefs(this).getString("pin", "").orEmpty()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(0xFFFFF0F7.toInt()); cornerRadius = dp(24).toFloat(); setStroke(dp(2), PINK) } }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun cardBg() = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0xFFE6D9FF.toInt()) }
        lateinit var render: () -> Unit
        render = {
            scope.launch {
                val rows = Db.get(this@BubbleService).d().allNow().filter { (cat.isEmpty() || it.category == cat) && (q.isBlank() || (it.title + it.content + it.category).contains(q, true)) }
                list.removeAllViews()
                if (rows.isEmpty()) list.addView(TextView(this@BubbleService).apply { text = "Belum ada teks 🌸"; setTextColor(INK) })
                rows.forEach { i ->
                    list.addView(TextView(this@BubbleService).apply {
                        text = (if (i.fav) "💗 " else "") + "${i.category} • ${i.title.ifBlank { "(tanpa judul)" }}\n${i.content.take(90)}"
                        setTextColor(INK); setPadding(dp(12), dp(10), dp(12), dp(10)); background = cardBg()
                        setOnClickListener { U.copyText(this@BubbleService, i.content, i.title); closePanel() }
                    }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
                }
            }
        }
        val top = LinearLayout(this).apply { gravity = CENTER_VERTICAL
            addView(TextView(this@BubbleService).apply { text = "💗 PinkVault Bubble"; textSize = 16f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btn("✕", true) { closePanel() }) }
        val chips = HorizontalScrollView(this).apply { addView(LinearLayout(this@BubbleService).apply {
            (listOf("Semua") + CATS).forEach { n -> addView(btn(n, true) { cat = if (n == "Semua") "" else n; render() }) } }) }
        val search = EditText(this).apply { hint = "🔍 Cari..."; setSingleLine(); setTextColor(INK)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { q = s.toString(); render() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {} }) }
        fun content() {
            root.removeAllViews(); root.addView(top); root.addView(chips); root.addView(search)
            root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        }
        if (pin.isEmpty()) content() else {
            root.addView(top)
            root.addView(EditText(this).apply { hint = "🔒 Masukkan PIN"; setSingleLine(); setTextColor(INK)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun afterTextChanged(s: android.text.Editable?) { if (s.toString() == pin) content() }
                    override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                    override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {} }) })
        }
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.92f).toInt(), (dm.heightPixels * 0.6f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = CENTER; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN }
        wm.addView(root, lp); panel = root
    }
}
