package com.pinkvault.app
import android.app.*
import android.content.*
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.*
import org.json.*

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

object U {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("pv", 0)
    fun copyText(c: Context, t: String, title: String) {
        (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("PinkVault", t))
        toast(c, "Tersalin 💗 Siap di-paste")
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("copy", "Notifikasi salin", NotificationManager.IMPORTANCE_DEFAULT))
        runCatching { nm.notify(2, Notification.Builder(c, "copy").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Berhasil disalin 💗").setContentText("${title.ifBlank { "Teks" }} siap di-paste")
            .setTimeoutAfter(2500).setAutoCancel(true).build()) }
    }
}

object Backup {
    suspend fun export(c: Context, out: Uri) = withContext(Dispatchers.IO) {
        val arr = JSONArray()
        Db.get(c).d().allNow().forEach { arr.put(JSONObject().put("title", it.title).put("content", it.content).put("category", it.category).put("fav", it.fav).put("at", it.createdAt)) }
        c.contentResolver.openOutputStream(out)!!.use { it.write(JSONObject().put("app", "pinkvault-bubble").put("items", arr).toString().toByteArray()) }
    }
    suspend fun restore(c: Context, src: Uri) = withContext(Dispatchers.IO) {
        val j = JSONObject(c.contentResolver.openInputStream(src)!!.use { it.readBytes().toString(Charsets.UTF_8) })
        require(j.optString("app") == "pinkvault-bubble")
        val arr = j.getJSONArray("items"); val d = Db.get(c).d(); d.clearAll()
        for (n in 0 until arr.length()) arr.getJSONObject(n).let {
            d.put(Item(title = it.getString("title"), content = it.getString("content"), category = it.getString("category"), fav = it.getBoolean("fav"), createdAt = it.getLong("at"))) }
    }
}
