package com.pinkvault.app
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val Pink = Color(0xFFFF8FBF); val PinkL = Color(0xFFFFE4F0); val Lav = Color(0xFFE6D9FF); val Ink = Color(0xFF5B3A55)
val Cute = FontFamily.SansSerif

@Composable fun PVTheme(dark: Boolean, content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = if (dark) darkColorScheme(primary = Pink, background = Color(0xFF2A1F2D), surface = Color(0xFF3A2B3F), primaryContainer = Color(0xFF4A3550), secondaryContainer = Color(0xFF50405A))
    else lightColorScheme(primary = Pink, onPrimary = Color.White, background = Color(0xFFFFF7FB), surface = Color.White, primaryContainer = PinkL, secondaryContainer = Lav, onBackground = Ink, onSurface = Ink),
    content = content)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent {
            val p = U.prefs(this)
            var dark by remember { mutableStateOf(p.getBoolean("dark", false)) }
            var unlocked by remember { mutableStateOf(p.getString("pin", "").isNullOrEmpty()) }
            PVTheme(dark) {
                if (!unlocked) PinScreen { unlocked = true } else App(dark) { dark = it; p.edit().putBoolean("dark", it).apply() }
            }
        }
    }
}

@Composable fun PinScreen(onOk: () -> Unit) {
    val c = LocalContext.current; var v by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("💗", fontSize = 64.sp); Text("Masukkan PIN", color = MaterialTheme.colorScheme.onBackground)
        OutlinedTextField(v, { v = it.filter(Char::isDigit); if (v == U.prefs(c).getString("pin", "")) onOk() }, visualTransformation = PasswordVisualTransformation(),
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
    }
}

@Composable fun App(dark: Boolean, setDark: (Boolean) -> Unit) {
    val c = LocalContext.current; val db = remember { Db.get(c) }; var tab by remember { mutableStateOf(0) }
    val all by db.d().all().collectAsState(emptyList())
    val tabs = listOf("🏠" to "Home", "📝" to "Teks", "💗" to "Favorit", "⚙️" to "Setelan")
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
        NavigationBar(containerColor = MaterialTheme.colorScheme.primaryContainer) {
            tabs.forEachIndexed { i, t -> NavigationBarItem(tab == i, { tab = i }, { Text(t.first) }, label = { Text(t.second, fontSize = 11.sp) }) } }
    }) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding()) {
            when (tab) {
                0 -> Home(all) { tab = it }
                1 -> TextScreen(all, db, true)
                2 -> TextScreen(all.filter { it.fav }, db, false)
                else -> SettingsScreen(dark, setDark)
            }
        }
    }
}

@Composable fun Home(all: List<Item>, go: (Int) -> Unit) {
    val c = LocalContext.current; val on = U.prefs(c).getBoolean("bubble", false)
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("PinkVault Bubble 💗", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Pink); Text("Floating Clipboard pribadimu ✨", color = MaterialTheme.colorScheme.onBackground) }
        item { Card(Modifier.fillMaxWidth().clickable { go(3) }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
            Column(Modifier.padding(16.dp)) { Text(if (on) "🫧 Bubble aktif" else "🫧 Bubble belum aktif", fontWeight = FontWeight.Bold)
                Text("${all.size} teks tersimpan · ${all.count { it.fav }} favorit"); if (!on) Text("Ketuk untuk mengaktifkan di Setelan", fontSize = 12.sp) } } }
        item { Text("Cara pakai: aktifkan bubble, buka WhatsApp/Twitter/Telegram/Instagram, ketuk bubble 💗, ketuk teks untuk menyalin, lalu Paste.", color = MaterialTheme.colorScheme.onBackground) }
        item { Text("Terbaru", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground) }
        items(all.take(3), key = { it.id }) { Row(Modifier.fillMaxWidth()) { Text("📝 ${it.title.ifBlank { it.content.take(30) }}", color = MaterialTheme.colorScheme.onBackground) } }
    }
}

@Composable fun TextScreen(list: List<Item>, db: Db, canAdd: Boolean) {
    val sc = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Item?>(null) }; var del by remember { mutableStateOf<Item?>(null) }
    val shown = list.filter { (cat.isEmpty() || it.category == cat) && (q.isBlank() || (it.title + it.content + it.category).contains(q, true)) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("🔍 Cari teks...") }, shape = RoundedCornerShape(20.dp), singleLine = true)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                items(CATS) { n -> FilterChip(cat == n, { cat = if (cat == n) "" else n }, { Text("$n (${list.count { it.category == n }})", fontSize = 12.sp) }) } }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                if (shown.isEmpty()) item { Text("Belum ada teks 🌸", color = MaterialTheme.colorScheme.onBackground) }
                items(shown, key = { it.id }) { i -> ItemCard(i, { sc.launch { db.d().put(i.copy(fav = !i.fav)) } }, { edit = i }, { del = i }) } }
        }
        if (canAdd) FloatingActionButton({ edit = Item(title = "", content = "", category = cat.ifEmpty { "Lainnya" }) }, Modifier.align(Alignment.BottomEnd).padding(16.dp), containerColor = Pink) { Text("＋", fontSize = 26.sp, color = Color.White) }
    }
    edit?.let { e -> EditDialog(e, { edit = null }) { n -> sc.launch { db.d().put(n) }; edit = null } }
    del?.let { d -> AlertDialog({ del = null }, title = { Text("Hapus teks?") }, text = { Text(d.title.ifBlank { d.content.take(40) }) },
        confirmButton = { Button({ sc.launch { db.d().del(d) }; del = null }) { Text("Hapus") } }, dismissButton = { TextButton({ del = null }) { Text("Batal") } }) }
}

@Composable fun ItemCard(i: Item, onFav: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val c = LocalContext.current
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(3.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(i.title.ifBlank { "(tanpa judul)" }, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("🏷️ ${i.category}", fontSize = 12.sp, color = Pink)
            Text(i.content, maxLines = 4, modifier = Modifier.padding(vertical = 6.dp))
            Row {
                Button({ U.copyText(c, i.content, i.title) }, shape = RoundedCornerShape(50)) { Text("📋 Salin") }
                TextButton(onFav) { Text(if (i.fav) "💗" else "🤍") }; TextButton(onEdit) { Text("✏️") }; TextButton(onDel) { Text("🗑️") }
            }
        }
    }
}

@Composable fun EditDialog(i: Item, onClose: () -> Unit, onSave: (Item) -> Unit) {
    var t by remember { mutableStateOf(i.title) }; var cat by remember { mutableStateOf(i.category) }; var body by remember { mutableStateOf(i.content) }
    AlertDialog(onDismissRequest = onClose, title = { Text(if (i.id == 0L) "Teks baru 💗" else "Edit ✏️") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(t, { t = it }, label = { Text("Judul") }, singleLine = true)
            Text("Kategori", fontSize = 12.sp)
            Column { CATS.chunked(2).forEach { r -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { r.forEach { n -> FilterChip(cat == n, { cat = n }, { Text(n, fontSize = 11.sp) }) } } } }
            OutlinedTextField(body, { body = it }, label = { Text("Isi teks (boleh panjang)") }, minLines = 5) } },
        confirmButton = { Button({ onSave(i.copy(title = t.trim(), content = body, category = cat)) }, enabled = body.isNotBlank()) { Text("Simpan") } },
        dismissButton = { TextButton(onClose) { Text("Batal") } })
}

@Composable fun SettingsScreen(dark: Boolean, setDark: (Boolean) -> Unit) {
    val c = LocalContext.current; val p = remember { U.prefs(c) }; val sc = rememberCoroutineScope(); val dm = c.resources.displayMetrics
    var on by remember { mutableStateOf(p.getBoolean("bubble", false)) }
    var size by remember { mutableStateOf(p.getInt("size", 56).toFloat()) }
    var yf by remember { mutableStateOf(p.getInt("by", (dm.heightPixels * 0.4f).toInt()).toFloat() / dm.heightPixels) }
    var pin by remember { mutableStateOf("") }
    fun apply() { val i = Intent(c, BubbleService::class.java); if (on) c.startForegroundService(i) else c.stopService(i) }
    fun side(left: Boolean) { p.edit().putInt("bx", if (left) 0 else dm.widthPixels - (p.getInt("size", 56) * dm.density).toInt()).apply(); if (on) apply() }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> u?.let { sc.launch { Backup.export(c, it); toast(c, "Backup selesai 💗") } } }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { sc.launch { runCatching { Backup.restore(c, it) }.onSuccess { toast(c, "Restore selesai 💗") }.onFailure { toast(c, "File backup tidak valid") } } } }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("⚙️ Setelan", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pink)
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Floating Bubble", Modifier.weight(1f))
            Switch(on, { v ->
                if (v && !Settings.canDrawOverlays(c)) {
                    c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName)))
                    toast(c, "Izinkan 'Tampil di atas aplikasi lain', lalu aktifkan lagi")
                } else { on = v; p.edit().putBoolean("bubble", v).apply()
                    if (v && Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS); apply() } }) }
        Text("Ukuran bubble: ${size.toInt()} dp")
        Slider(size, { size = it; p.edit().putInt("size", it.toInt()).apply() }, valueRange = 40f..90f, onValueChangeFinished = { if (on) apply() })
        Text("Posisi vertikal")
        Slider(yf, { yf = it }, valueRange = 0.05f..0.85f, onValueChangeFinished = { p.edit().putInt("by", (yf * dm.heightPixels).toInt()).apply(); if (on) apply() })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton({ side(true) }) { Text("⬅ Sisi kiri") }; OutlinedButton({ side(false) }) { Text("Sisi kanan ➡") } }
        Text("Bubble bisa digeser langsung & akan menempel ke sisi layar.", fontSize = 12.sp)
        Button({ c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))) }) { Text("Pengaturan izin aplikasi") }
        HorizontalDivider()
        Text("Proteksi PIN" + if (!p.getString("pin", "").isNullOrEmpty()) " (aktif — juga mengunci panel bubble)" else "", fontWeight = FontWeight.Bold)
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("PIN baru (min. 4 angka)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ if (pin.length >= 4) { p.edit().putString("pin", pin).apply(); pin = ""; toast(c, "PIN disimpan") } else toast(c, "Minimal 4 angka") }) { Text("Simpan PIN") }
            OutlinedButton({ p.edit().remove("pin").apply(); toast(c, "PIN dihapus") }) { Text("Hapus PIN") } }
        HorizontalDivider()
        Text("Backup & Restore", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ exp.launch("pinkvault-bubble-backup.json") }) { Text("Backup") }
            OutlinedButton({ imp.launch(arrayOf("application/json", "application/octet-stream", "text/plain")) }) { Text("Restore") } }
        Text("Restore menggantikan semua teks yang ada.", fontSize = 12.sp)
        HorizontalDivider()
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Tema gelap", Modifier.weight(1f)); Switch(dark, setDark) }
    }
}
