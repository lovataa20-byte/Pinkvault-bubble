package com.pinkvault.app
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

val CATS = listOf("Promosi", "Caption", "Template Chat", "Balasan Pelanggan", "Informasi Pembayaran", "Lainnya")

@Entity data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val content: String,
    val category: String = "Lainnya", val fav: Boolean = false, val createdAt: Long = System.currentTimeMillis())

@Dao interface D {
    @Query("SELECT * FROM Item ORDER BY createdAt DESC") fun all(): Flow<List<Item>>
    @Query("SELECT * FROM Item ORDER BY fav DESC, createdAt DESC") suspend fun allNow(): List<Item>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(i: Item): Long
    @Delete suspend fun del(i: Item)
    @Query("DELETE FROM Item") suspend fun clearAll()
}
@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun d(): D
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "pvbubble.db").build().also { I = it } }
    }
}
