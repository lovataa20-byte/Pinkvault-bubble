# PinkVault Bubble – Floating Clipboard
1. Buka folder ini di Android Studio (Koala 2024.1+, JDK 17), tunggu Gradle sync.
2. Build > Build APK(s) -> `app/build/outputs/apk/release/app-release.apk` (ditandatangani kunci debug agar bisa langsung diinstal), atau `gradle wrapper && ./gradlew assembleRelease`.
3. Di HP: buka app > Setelan > aktifkan Floating Bubble > izinkan "Tampil di atas aplikasi lain" > aktifkan lagi.
